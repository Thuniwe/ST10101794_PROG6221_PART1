﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221_Part2
{
    public class Recipe
    {
        // Properties of the Recipe class
        public string ingName { get; set; }
        public Dictionary<string, Ingredient> Ingredients { get; set; }
        public int TotalCalories { get; set; }
        public int numberOfSteps { get; set; }
        public List<string> Steps { get; set; }

        // Constructor for the Recipe class
        public Recipe(string name)
        {
            // Initialize the properties of the Recipe class
            ingName = name;
            Ingredients = new Dictionary<string, Ingredient>();
            TotalCalories = 0;
            numberOfSteps = 0;
            Steps = new List<string>();
        }

        // Method to add an ingredient to the recipe
        public void AddIngredient(string name, int quantity,string UOF, int calories, string foodGroup)
        {
            // Create a new Ingredient object and add it to the Ingredients dictionary
            Ingredients[name] = new Ingredient(quantity, UOF, calories, foodGroup);
            // Update the TotalCalories property of the Recipe class
            TotalCalories += quantity * calories;
        }

        // Method to add a step to the recipe
        public void AddStep(string description)
        {
            // Add the step to the Steps list and increment the numberOfSteps property
            Steps.Add(description);
            numberOfSteps++;
        }
        public int QuantityCloned { get; set; } //creating a property to store the cloned quantity
        public void Scale(double factor)
        {
            // Method to scale the recipe by a given factor
            Dictionary<string, Ingredient> clonedIngredient = new Dictionary<string, Ingredient>(Ingredients);
            
            // Scale the quantity of each ingredient in the cloned dictionary
            foreach (var ingredient in clonedIngredient.Values)
            {
                //using the property declared
                QuantityCloned = (int)Math.Round(ingredient.ingQuantity * factor);
            }
            // Print the scaled recipe

            foreach (var ingredient in clonedIngredient)
            {
                Console.WriteLine($"{QuantityCloned} {ingredient.Value.UnitOfMeaurement} of {ingredient.Key}" +
                    $"\nCalories per quantity: {ingredient.Value.Calories} \nFood group: {ingredient.Value.FoodGroup})\n" );
            }
            Console.WriteLine("Steps");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}\n");
            }

        }
        // Method to reset the recipe to its initial state
        public void Reset()
        {
            // Reset the TotalCalories property and the quantity of each ingredient
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Value.ingQuantity} {ingredient.Value.UnitOfMeaurement} of {ingredient.Key}" +
                    $" \nCalories per quantity: {ingredient.Value.Calories} \nFood group: {ingredient.Value.FoodGroup}");
            }
            
        }
        // Method to convert the Recipe object to a string
        public override string ToString()
        {
            Console.WriteLine();
            string result = $"Recipe: {ingName}\n";
            result += $"Total calories: {TotalCalories}\n";
            result += $"Total steps: {numberOfSteps}\n";
            result += "Ingredients\n";

            foreach (var ingredient in Ingredients)
            {
                result += $"{ingredient.Value.ingQuantity} {ingredient.Value.UnitOfMeaurement} of {ingredient.Key}" +
                    $" \nTotal Calories per quantity: {ingredient.Value.Calories} \nFoodGroup: {ingredient.Value.FoodGroup}\n";
            }

            result += "Steps:\n";

            for (int i = 0; i < Steps.Count; i++)
            {
                result += $"{i + 1}. {Steps[i]}\n";
            }
            if (TotalCalories > 300)
            {
                Console.WriteLine("WARNING: This recipe exceeds 300 calories!");
            }

            return result;
        }
    }
}
