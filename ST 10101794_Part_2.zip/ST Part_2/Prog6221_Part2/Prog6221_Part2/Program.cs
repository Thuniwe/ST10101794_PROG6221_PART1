﻿namespace Prog6221_Part2
{
    public class Program
    {
        static void Main(string[] args)
        {
            RecipeManager recipeManager = new RecipeManager(); //calling RecipeManager class
            bool isRunning = true;

            while (isRunning)
            {
                //displaying options to user
                Console.WriteLine("Welcome to the Recipe App!");
                Console.WriteLine("Please choose an option:");
                Console.WriteLine("1. Add a recipe");
                Console.WriteLine("2. Display a recipe");
                Console.WriteLine("3. Scale a recipe");
                Console.WriteLine("4. Reset a recipe");
                Console.WriteLine("5. Clear all recipes");
                Console.WriteLine("6. List all recipes");
                Console.WriteLine("7. Exit");
                Console.WriteLine();

                try
                {
                    int option = int.Parse(Console.ReadLine());

                    if (option == 1) { recipeManager.AddRecipe(); } //calling enter recipe method
                    else if (option == 2) { recipeManager.DisplayRecipe(); }
                    else if (option == 3)
                    {
                        Console.Write("\nEnter scale factor (0,5 OR 2 OR 3): ");
                        double factor = double.Parse(Console.ReadLine());
                        if (factor == 0.5)
                        {
                            recipeManager.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else if (factor == 2)
                        {
                            recipeManager.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else if (factor == 3)
                        {
                            recipeManager.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else
                        {
                            Console.WriteLine("You entered the wrong option. \nPlease enter again");
                        }
                    }
                    else if (option == 4)
                    {
                        recipeManager.ResetRecipe();
                    }
                    else if (option == 5) { recipeManager.ClearRecipes(); } //calling reset recipe method
                    else if (option == 6) { recipeManager.ListRecipes(); } //calling clear recipe method
                    else if (option == 7) { Environment.Exit(0); }
                    else
                    {
                        Console.WriteLine("Invalid option. Please Select from the given options");
                    }

                    Console.WriteLine();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                
            }
        }
    }
}