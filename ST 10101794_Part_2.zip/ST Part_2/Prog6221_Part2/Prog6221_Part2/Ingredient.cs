﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221_Part2
{
    public class Ingredient
    {
        // Properties of the Ingredient class
        public int ingQuantity { get; set; }
        public string UnitOfMeaurement { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
        // Constructor for the Ingredient class
        public Ingredient(int quantity,string unitOfMeasurement, int calories, string foodGroup)
        {
            // Initialize the properties of the Ingredient class
            ingQuantity = quantity;
            UnitOfMeaurement = unitOfMeasurement;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}
