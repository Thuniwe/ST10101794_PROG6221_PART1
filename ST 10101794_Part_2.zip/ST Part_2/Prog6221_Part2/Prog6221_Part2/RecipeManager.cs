﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221_Part2
{
    public class RecipeManager
    {
        // Properties of the RecipeManager class
        private List<Recipe> recipes;
        
        public RecipeManager() // Constructor for the RecipeManager class
        {
            recipes = new List<Recipe>();
        }

        public void AddRecipe() // Method to add a new recipe
        {
            Console.WriteLine();
            Console.WriteLine("Please enter the name of the recipe:");
            string name = Console.ReadLine();

            Recipe recipe = new Recipe(name);

            bool exit = false;

            while (!exit)
            {
                try
                {
                    Console.WriteLine("Please choose an option:");
                    Console.WriteLine("1. Add an ingredient");
                    Console.WriteLine("2. Add a step");
                    Console.WriteLine("3. Finish recipe");

                    string input = Console.ReadLine();

                    switch (input)
                    {
                        case "1":
                            Console.Write("Please enter the name of the ingredient >> ");
                            string ingredientName = Console.ReadLine();

                            Console.Write("Please enter the quantity of the ingredient >> ");
                            int quantity = int.Parse(Console.ReadLine());

                            Console.Write("Please enter the unit of Measurement >> ");
                            string UOF = Console.ReadLine();

                            Console.Write("Please enter the number of calories per unit of the ingredient >> ");
                            int calories = int.Parse(Console.ReadLine());

                            Console.Write("Please enter the food group of the ingredient >> ");
                            string foodGroup = Console.ReadLine();

                            recipe.AddIngredient(ingredientName, quantity, UOF, calories, foodGroup);
                            break;
                        case "2":
                            Console.Write("Please enter the description of the step >> ");
                            string description = Console.ReadLine();
                            recipe.AddStep(description);
                            break;
                        case "3":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid option. Please try again.");
                            break;
                    }

                    Console.WriteLine();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                
            }

            recipes.Add(recipe);
            Console.WriteLine($"Recipe '{name}' added successfully.");
        }

        public void ScaleRecipe(double factor) // Method to scale a recipe by a given factor
        {
            Console.WriteLine();
            Console.WriteLine("Please enter the name of the recipe to scale:");
            string name = Console.ReadLine();
            Console.WriteLine();
            Recipe recipe = recipes.FirstOrDefault(r => r.ingName == name);

            if (recipe == null)
            {
                Console.WriteLine($"Recipe '{name}' not found.");
                return;
            }

            //Console.WriteLine("Please enter the scaling factor (0.5, 2, or 3):");
            //double factor = double.Parse(Console.ReadLine());

            recipe.Scale(factor);
            Console.WriteLine($"Recipe '{name}' scaled by {factor}.");
        }

        public void ResetRecipe() // Method to reset a recipe
        {
            Console.WriteLine();
            Console.WriteLine("Please enter the name of the recipe to reset:");
            string name = Console.ReadLine();
            Console.WriteLine();
            Recipe recipe = recipes.FirstOrDefault(r => r.ingName == name);

            if (recipe == null)
            {
                Console.WriteLine($"Recipe '{name}' not found.");
                return;
            }

            recipe.Reset();
            Console.WriteLine($"Recipe '{name}' reset successfully.");
        }

        public void ClearRecipes() // Method to clear all recipes
        {
            Console.WriteLine();
            recipes.Clear();
            Console.WriteLine("All recipes cleared successfully.");
        }

        public void ListRecipes() // Method to list all recipes
        {
            Console.WriteLine();
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Recipes:");

            foreach (var recipe in recipes.OrderBy(r => r.ingName)) //sort in ascending order
            {
                Console.WriteLine($"- {recipe.ingName}");
            }
        }

        public void DisplayRecipe() // Method to display a recipe
        {
            Console.WriteLine();
            Console.WriteLine("Please enter the name of the recipe to display:");
            string name = Console.ReadLine();

            Recipe recipe = recipes.FirstOrDefault(r => r.ingName == name);

            if (recipe == null)
            {
                Console.WriteLine($"Recipe '{name}' not found.");
                return;
            }

            Console.WriteLine(recipe);
        }
        // Method to notify if a recipe's total calories exceed a limit
        public void NotifyIfCaloriesExceedLimit(Recipe recipe)
        {
            if (recipe.TotalCalories > 300)
            {
                Console.WriteLine($"Warning: Recipe '{recipe.ingName}' has {recipe.TotalCalories} calories.");
            }
        }
    }
}
