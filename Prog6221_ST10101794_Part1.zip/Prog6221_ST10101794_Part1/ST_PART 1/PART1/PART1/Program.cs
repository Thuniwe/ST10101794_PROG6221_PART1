﻿namespace PART1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Recipe recipe = new Recipe(); //calling the recipe class
            bool Application = true; //declaring a boolean variable

            while (Application)
            {
                Console.WriteLine("Choose from the following options what you'd like to do");
                try//using error handling should the user enter the wrong input
                {
                    //Getting user input
                    Console.WriteLine("1. Enter the details for a recipe");
                    Console.WriteLine("2. Display the full recipe");
                    Console.WriteLine("3. Scale the recipe");
                    Console.WriteLine("4. Reset the quantities to Original values");
                    Console.WriteLine("5. Clear all the data");
                    Console.WriteLine("6. Exit");
                    Console.WriteLine();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                //creating a variable to store the user input
                int option = Convert.ToInt32(Console.ReadLine());

                if (option == 1) { recipe.EnterRecipe(); } //calling enter recipe method
                else if (option == 2) { recipe.DisplayRecipe(); }//calling display recipe method

                else if (option == 3) {
                    try
                    {
                        Console.Write("\nEnter scale factor (0,5 OR 2 OR 3): ");
                        double factor = double.Parse(Console.ReadLine());
                        if (factor == 0.5)
                        {
                            recipe.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else if (factor == 2)
                        {
                            recipe.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else if (factor == 3)
                        {
                            recipe.ScaleRecipe(factor);  //calling scale recipe method
                        }
                        else
                        {
                            Console.WriteLine("You entered the wrong option. \nPlease enter again");
                        }
                    }
                    catch (Exception u)
                    {
                        Console.WriteLine(u.Message);
                    }
                    
                }
                else if (option == 4){ recipe.ResetQuantities(); } //calling reset recipe method
                else if (option == 5) { recipe.ClearAllData(); } //calling clear recipe method
                else if (option == 6) { Environment.Exit(0); }
                else 
                {
                    Console.WriteLine("Please Select from the given options");
                }



            }
        }
    }
}